package student;

import provided.BinarySequence;

public class HuffmanNode {
// TODO

}
