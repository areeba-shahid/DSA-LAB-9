package student;

import provided.BinarySequence;

// you may implement any interface you want here
public class HuffmanCodeBook {
// TODO
}
